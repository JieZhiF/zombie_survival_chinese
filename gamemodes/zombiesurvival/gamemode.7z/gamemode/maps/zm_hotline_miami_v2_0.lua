hook.Add("InitPostEntityMap", "Adding", function()
	util.RemoveAll("trigger_teleport")
end)
