CLASS.Base = "gore_child"

CLASS.Hidden = true

CLASS.Name = "Shadow Child"
CLASS.TranslationName = "class_shadow_gore_child"
CLASS.Description = "description_shadow_gore_child"
CLASS.Help = "controls_shadow_gore_child"

CLASS.Health = 15
CLASS.Speed = 155

CLASS.Points = 0.5

CLASS.SWEP = "weapon_zs_shadowgorechild"

CLASS.OverrideModel = Model("models/player/skeleton.mdl")

CLASS.NoHideMainModel = true
