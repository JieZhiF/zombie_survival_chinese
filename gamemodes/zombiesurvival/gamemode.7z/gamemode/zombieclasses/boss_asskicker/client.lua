include("shared.lua")

CLASS.Icon = "zombiesurvival/killicons/legs"
