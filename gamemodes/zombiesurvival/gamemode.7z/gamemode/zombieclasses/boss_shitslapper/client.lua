include("shared.lua")

CLASS.Icon = "zombiesurvival/killicons/torso"
