include("shared.lua")

CLASS.Icon = "sprites/glow04_noz"

function CLASS:PrePlayerDraw(pl)
	return true
end
